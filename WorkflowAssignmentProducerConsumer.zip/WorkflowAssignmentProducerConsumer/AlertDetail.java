package WorkflowAssignmentProducerConsumer;

public class AlertDetail {

    String alertNo;

    public AlertDetail(String alertNo) {
        this.alertNo = alertNo;
    }

    public String getAlertNo() {
        return alertNo;
    }

    public void setAlertNo(String alertNo) {
        this.alertNo = alertNo;
    }

}
